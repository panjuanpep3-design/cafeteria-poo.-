# Sistema de Cafetería Universitaria (Java + POO)

Programa que cobra el almuerzo a los miembros de la comunidad universitaria
(estudiantes, docentes y administrativos), aplicando un descuento distinto según el tipo
de miembro y descontando el valor del saldo de su carné.

## Integrantes
- Nombre 1 (código)
- Nombre 2 (código)

## Estructura
```
src/
  MiembroComunidad.java   (clase abstracta)
  Estudiante.java         (20 % de descuento)
  Docente.java            (10 % de descuento)
  Administrativo.java     (15 % de descuento)
  Carne.java              (saldo encapsulado)
  Cafeteria.java          (main + cobrar)
diagrama_de_clases.png
```

## Cómo ejecutarlo
```
cd src
javac *.java
java Cafeteria
```

## Salida esperada
```
Laura Gómez paga $9600 (saldo restante: $10400)
Carlos Ruiz no tiene saldo suficiente para pagar $10800
Marta Pérez paga $10200 (saldo restante: $4800)
```
