# Aplicación de los pilares de la POO en el proyecto

**Proyecto:** Sistema de Cafetería Universitaria (Java)

## 1. Abstracción
La clase `MiembroComunidad` es abstracta y modela solo lo que la cafetería necesita de
cualquier persona de la universidad: nombre, código, carné y el descuento que le
corresponde. Se ignoran datos que no importan para este problema (promedio, dirección,
etc.). El método `descuentoCafeteria()` está declarado como `abstract`: la clase promete
que existe sin decir cómo se calcula. Además, `new MiembroComunidad(...)` no compila,
porque un "miembro" genérico no existe; siempre es estudiante, docente o administrativo.

## 2. Encapsulamiento
En la clase `Carne`, el atributo `saldo` es `private`. Nadie fuera de la clase puede
modificarlo directamente; solo se cambia con `recargar(valor)`, que rechaza valores no
positivos lanzando una excepción, y `pagar(valor)`, que devuelve `false` si el valor es
inválido o el saldo no alcanza. No existe un `setSaldo`, porque permitiría saltarse esas
validaciones. Así el objeto protege su propio estado y el saldo nunca queda negativo.
Lo mismo ocurre con los atributos `nombre`, `codigo`, `semestre`, `facultad` y
`dependencia`, que son privados y se consultan con getters.

## 3. Herencia
`Estudiante`, `Docente` y `Administrativo` heredan de `MiembroComunidad` (`extends`).
Reutilizan `nombre`, `codigo`, `carne`, `getNombre()`, `getCodigo()` y `getCarne()` sin
reescribirlos, y construyen la parte heredada con `super(nombre, codigo)`. Cada subclase
agrega lo propio: `semestre` (Estudiante), `facultad` (Docente) y `dependencia`
(Administrativo). La relación "es un" es correcta: un docente *es un* miembro de la
comunidad. En cambio, `Carne` no hereda: un miembro *tiene un* carné, por eso se usa
composición (un atributo `Carne` dentro de `MiembroComunidad`).

## 4. Polimorfismo
Cada subclase sobrescribe (`@Override`) `descuentoCafeteria()`: 0.20 en `Estudiante`,
0.10 en `Docente` y 0.15 en `Administrativo`. En `Cafeteria.cobrar(MiembroComunidad m,
double precio)` se usa una referencia del tipo padre y se llama `m.descuentoCafeteria()`;
la versión que se ejecuta depende del objeto real, sin ningún `if` ni `instanceof`.
Por eso, al agregar la clase `Administrativo` no hubo que modificar ninguna línea de
`Cafeteria`: basta con que la nueva clase sobrescriba el método.

## Resumen
| Pilar | Dónde | Evidencia en el código |
|---|---|---|
| Abstracción | `MiembroComunidad` | clase `abstract` y método `descuentoCafeteria()` abstracto |
| Encapsulamiento | `Carne` | `saldo` privado, solo `recargar()` y `pagar()` con validación |
| Herencia | `Estudiante`, `Docente`, `Administrativo` | `extends MiembroComunidad` y `super(...)` |
| Polimorfismo | `Cafeteria.cobrar()` | `m.descuentoCafeteria()` con referencia del tipo padre |
