import java.util.ArrayList;
import java.util.List;

public class Cafeteria {

    /** Polimorfismo: funciona con cualquier MiembroComunidad sin usar if/instanceof. */
    public static boolean cobrar(MiembroComunidad m, double precio) {
        double total = precio * (1 - m.descuentoCafeteria());
        boolean ok = m.getCarne().pagar(total); // no lee ni modifica el saldo directamente
        if (ok) {
            System.out.printf("%s paga $%.0f (saldo restante: $%.0f)%n",
                    m.getNombre(), total, m.getCarne().getSaldo());
        } else {
            System.out.printf("%s no tiene saldo suficiente para pagar $%.0f%n",
                    m.getNombre(), total);
        }
        return ok;
    }

    public static void main(String[] args) {
        List<MiembroComunidad> fila = new ArrayList<>();
        fila.add(new Estudiante("Laura Gómez", "E-1024", 2));
        fila.add(new Docente("Carlos Ruiz", "D-0311", "Ingeniería"));
        fila.add(new Administrativo("Marta Pérez", "A-0057", "Bienestar"));

        // Recargas (encapsulamiento: solo mediante recargar())
        fila.get(0).getCarne().recargar(20000);
        fila.get(1).getCarne().recargar(5000);   // saldo insuficiente a propósito
        fila.get(2).getCarne().recargar(15000);

        double precioAlmuerzo = 12000;
        for (MiembroComunidad m : fila) {
            cobrar(m, precioAlmuerzo);
        }
    }
}
