/**
 * Pilar: ABSTRACCIÓN. Modela solo lo que la cafetería necesita de una persona
 * de la universidad. No se puede instanciar: siempre es un tipo concreto.
 * Relación "tiene un": cada miembro tiene un Carne (composición).
 */
public abstract class MiembroComunidad {
    private String nombre;
    private String codigo;
    private Carne carne;

    public MiembroComunidad(String nombre, String codigo) {
        this.nombre = nombre;
        this.codigo = codigo;
        this.carne = new Carne();
    }

    public String getNombre() { return nombre; }
    public String getCodigo() { return codigo; }
    public Carne getCarne()   { return carne; }

    // Todos tienen descuento, pero cada tipo lo define a su manera
    public abstract double descuentoCafeteria();
}
